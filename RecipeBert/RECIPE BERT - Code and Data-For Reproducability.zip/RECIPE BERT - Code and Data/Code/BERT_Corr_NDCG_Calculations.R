#install.packages("dplyr")
#install.packages("DescTools")
library(dplyr)
#install.packages("DescTools")
library(DescTools)
library(data.table)

setwd("")

#---------- Reading file with model scores -------------- #
bert_data_cv1 <- read.csv("jeevan_cv_run1_all_models_combined_validation_data_output_v2.csv", header = TRUE)
head(bert_data_cv1)

#--------- Renaming various columns ------------------- #
names(bert_data_cv1)[names(bert_data_cv1) == 'Similarity'] <- 'gs_similarity'
names(bert_data_cv1)[names(bert_data_cv1) == 'Bert_similarity'] <- 'bert_similarity'
names(bert_data_cv1)[names(bert_data_cv1) == 'Fine_Tuned_Bert_Similarity'] <- 'fine_tuned_bert_similarity_5_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Fine_Tuned_Bert_Similarity_10_epoc'] <- 'fine_tuned_bert_similarity_10_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Fine_Tuned_Bert_Similarity_20_epoc'] <- 'fine_tuned_bert_similarity_20_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Fine_Tuned_Bert_Similarity_40_epoc'] <- 'fine_tuned_bert_similarity_40_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Few_Layers_Bert_Similarity_v1'] <- 'few_layers_bert_similarity_v1'
names(bert_data_cv1)[names(bert_data_cv1) == 'Few_Layers_Bert_Similarity_v2'] <- 'few_layers_bert_similarity_v2'
names(bert_data_cv1)[names(bert_data_cv1) == 'Robert_base_Similarity'] <- 'robert_base_similarity'
names(bert_data_cv1)[names(bert_data_cv1) == 'Robert_Similarity_5_epoc'] <- 'robert_similarity_5_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Robert_Similarity_20_epoc'] <- 'robert_similarity_20_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Robert_Similarity_50_epoc'] <- 'robert_similarity_50_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Add_New_Layer_Model_30_EPOC'] <- 'add_new_layer_bert_similarity_30_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Add_New_Layer_Model_50_EPOC'] <- 'add_new_layer_bert_similarity_50_epoc'
names(bert_data_cv1)[names(bert_data_cv1) == 'Add_New_Layer_Model_100_EPOC'] <- 'add_new_layer_bert_similarity_100_epoc'

#----------- Selecting only required columns ----------------- #
bert_data_cv1 <- bert_data_cv1[,c("title_Recipe1_mod", 
                                  "title_Recipe2_mod",
                                  "gs_similarity", 
                                  "tfidf_similarity", 
                                  "bert_similarity",
                                  
                                  "fine_tuned_bert_similarity_5_epoc",
                                  "fine_tuned_bert_similarity_10_epoc",
                                  "fine_tuned_bert_similarity_20_epoc",
                                  "fine_tuned_bert_similarity_40_epoc",
                                  
                                  "robert_base_similarity",
                                  "robert_similarity_5_epoc",
                                  "robert_similarity_20_epoc", 
                                  "robert_similarity_50_epoc",
                                  
                                  "few_layers_bert_similarity_v1",
                                  "few_layers_bert_similarity_v2",
                                  
                                  'add_new_layer_bert_similarity_30_epoc',
                                  'add_new_layer_bert_similarity_50_epoc',
                                  'add_new_layer_bert_similarity_100_epoc'
)]

#----------- Ranking based on similarity scores -------------- #
bert_data_cv1_rank <- bert_data_cv1 %>% 
  arrange(title_Recipe1_mod, title_Recipe2_mod) %>%
  group_by(title_Recipe1_mod) %>% 
  mutate(gs_rank = rank(-gs_similarity, ties.method = "min"),
         tfidf_rank = rank(-tfidf_similarity, ties.method = "min"),
         bert_rank = rank(-bert_similarity, ties.method = "min"),
         
         fine_tuned_bert_similarity_5_epoc_rank = rank(-fine_tuned_bert_similarity_5_epoc, ties.method = "min"),
         fine_tuned_bert_similarity_10_epoc_rank = rank(-fine_tuned_bert_similarity_10_epoc, ties.method = "min"),
         fine_tuned_bert_similarity_20_epoc_rank = rank(-fine_tuned_bert_similarity_20_epoc, ties.method = "min"),
         fine_tuned_bert_similarity_40_epoc_rank = rank(-fine_tuned_bert_similarity_40_epoc, ties.method = "min"),
         
         robert_similarity_base_rank = rank(-robert_base_similarity, ties.method = "min"),
         robert_similarity_5_epoc_rank = rank(-robert_similarity_5_epoc, ties.method = "min"),
         robert_similarity_20_epoc_rank = rank(-robert_similarity_20_epoc, ties.method = "min"),
         robert_similarity_50_epoc_rank = rank(-robert_similarity_50_epoc, ties.method = "min"),
         
         few_layers_bert_similarity_v1_rank = rank(-few_layers_bert_similarity_v1, ties.method = "min"),
         few_layers_bert_similarity_v2_rank = rank(-few_layers_bert_similarity_v2, ties.method = "min"),
         
         add_new_layer_bert_similarity_30_epoc_rank = rank(-add_new_layer_bert_similarity_30_epoc, ties.method = "min"),
         add_new_layer_bert_similarity_50_epoc_rank = rank(-add_new_layer_bert_similarity_50_epoc, ties.method = "min"),
         add_new_layer_bert_similarity_100_epoc_rank = rank(-add_new_layer_bert_similarity_100_epoc, ties.method = "min")
  )


bert_data_cv1_size <- bert_data_cv1 %>%
  group_by(title_Recipe1_mod) %>%
  dplyr::summarise(tot_recipes_2 = n_distinct(title_Recipe2_mod)) %>%
  filter(tot_recipes_2 >= 5)

bert_data_cv1_rank <- inner_join(bert_data_cv1_rank, bert_data_cv1_size, by = "title_Recipe1_mod")

#----------- To get number of unique recipes in recipe 1 and recipe 2 ---------------- #

n_distinct(bert_data_cv1_rank$title_Recipe1_mod)

#------------- Calculating correlations --------------------------------------------#
bert_output <- bert_data_cv1_rank %>%
  group_by(title_Recipe1_mod) %>%
  dplyr::summarise(size = n(),
                   
                   tfidf_gs_corr_sp = cor(gs_rank, tfidf_rank, method = "spearman"),
                   bert_gs_corr_sp = cor(gs_rank, bert_rank, method = "spearman"),
                   
                   fine_tuned_bert_5_epoc_gs_corr_sp = cor(gs_rank, fine_tuned_bert_similarity_5_epoc_rank, method = "spearman"),
                   fine_tuned_bert_10_epoc_gs_corr_sp = cor(gs_rank, fine_tuned_bert_similarity_10_epoc_rank, method = "spearman"),
                   fine_tuned_bert_20_epoc_gs_corr_sp = cor(gs_rank, fine_tuned_bert_similarity_20_epoc_rank, method = "spearman"),
                   fine_tuned_bert_40_epoc_gs_corr_sp = cor(gs_rank, fine_tuned_bert_similarity_40_epoc_rank, method = "spearman"),
                   
                   few_layers_bert_v1_gs_corr_sp = cor(gs_rank, few_layers_bert_similarity_v1_rank, method = "spearman"),
                   few_layers_bert_v2_gs_corr_sp = cor(gs_rank, few_layers_bert_similarity_v2_rank, method = "spearman"),
                   
                   robert_base_gs_corr_sp = cor(gs_rank, robert_similarity_base_rank, method = "spearman"),
                   robert_5_epoc_gs_corr_sp = cor(gs_rank, robert_similarity_5_epoc_rank, method = "spearman"),
                   robert_20_epoc_gs_corr_sp = cor(gs_rank, robert_similarity_20_epoc_rank, method = "spearman"),
                   robert_50_epoc_gs_corr_sp = cor(gs_rank, robert_similarity_50_epoc_rank, method = "spearman"),
                   
                   add_new_layer_bert_30_epoc_gs_corr_sp = cor(gs_rank, add_new_layer_bert_similarity_30_epoc_rank, method = "spearman"),
                   add_new_layer_bert_50_epoc_gs_corr_sp = cor(gs_rank, add_new_layer_bert_similarity_50_epoc_rank, method = "spearman"),
                   add_new_layer_bert_100_epoc_gs_corr_sp = cor(gs_rank, add_new_layer_bert_similarity_100_epoc_rank, method = "spearman"),
                   
                   
                   
                   tfidf_gs_corr_kendall = cor(gs_rank, tfidf_rank, method = "kendall"),
                   bert_gs_corr_kendall = cor(gs_rank, bert_rank, method = "kendall"),
                   
                   fine_tuned_bert_5_epoc_gs_corr_kendall = cor(gs_rank, fine_tuned_bert_similarity_5_epoc_rank, method = "kendall"),
                   fine_tuned_bert_10_epoc_gs_corr_kendall = cor(gs_rank, fine_tuned_bert_similarity_10_epoc_rank, method = "kendall"),
                   fine_tuned_bert_20_epoc_gs_corr_kendall = cor(gs_rank, fine_tuned_bert_similarity_20_epoc_rank, method = "kendall"),
                   fine_tuned_bert_40_epoc_gs_corr_kendall = cor(gs_rank, fine_tuned_bert_similarity_40_epoc_rank, method = "kendall"),
                   
                   few_layers_bert_v1_gs_corr_kendall = cor(gs_rank, few_layers_bert_similarity_v1_rank, method = "kendall"),
                   few_layers_bert_v2_gs_corr_kendall = cor(gs_rank, few_layers_bert_similarity_v2_rank, method = "kendall"),
                   
                   robert_base_gs_corr_kendall = cor(gs_rank, robert_similarity_base_rank, method = "kendall"),
                   robert_5_epoc_gs_corr_kendall = cor(gs_rank, robert_similarity_5_epoc_rank, method = "kendall"),
                   robert_20_epoc_gs_corr_kendall = cor(gs_rank, robert_similarity_20_epoc_rank, method = "kendall"),
                   robert_50_epoc_gs_corr_kendall = cor(gs_rank, robert_similarity_50_epoc_rank, method = "kendall"),
                   
                   add_new_layer_bert_30_epoc_gs_corr_kendall = cor(gs_rank,  add_new_layer_bert_similarity_30_epoc_rank, method = "kendall"),
                   add_new_layer_bert_50_epoc_gs_corr_kendall = cor(gs_rank,  add_new_layer_bert_similarity_50_epoc_rank, method = "kendall"),
                   add_new_layer_bert_100_epoc_gs_corr_kendall = cor(gs_rank,  add_new_layer_bert_similarity_100_epoc_rank, method = "kendall"),
                   
                   
                   tfidf_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, tfidf_rank),
                   bert_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, bert_rank),
                   
                   fine_tuned_bert_5_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, fine_tuned_bert_similarity_5_epoc),
                   fine_tuned_bert_10_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, fine_tuned_bert_similarity_10_epoc_rank),
                   fine_tuned_bert_20_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, fine_tuned_bert_similarity_20_epoc_rank),
                   fine_tuned_bert_40_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, fine_tuned_bert_similarity_40_epoc_rank),
                   
                   few_layers_bert_v1_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, few_layers_bert_similarity_v1_rank),
                   few_layers_bert_v2_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, few_layers_bert_similarity_v2_rank),
                   
                   robert_base_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, robert_similarity_base_rank),
                   robert_5_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, robert_similarity_5_epoc_rank),
                   robert_20_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, robert_similarity_20_epoc_rank),
                   robert_50_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, robert_similarity_50_epoc_rank),
                   
                   add_new_layer_bert_30_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, add_new_layer_bert_similarity_30_epoc_rank),
                   add_new_layer_bert_50_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, add_new_layer_bert_similarity_50_epoc_rank),
                   add_new_layer_bert_100_epoc_gs_corr_gamma = GoodmanKruskalGamma(gs_rank, add_new_layer_bert_similarity_100_epoc_rank)
                   
                   
                   
  )

#--------------- Getting medians of various correlations ----------------- #
output = data.frame(
  c(
    median(bert_output$tfidf_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$bert_gs_corr_gamma, na.rm = TRUE),
    
    median(bert_output$fine_tuned_bert_5_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_10_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_20_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_40_epoc_gs_corr_gamma, na.rm = TRUE),
    
    median(bert_output$few_layers_bert_v1_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$few_layers_bert_v2_gs_corr_gamma, na.rm = TRUE),
    
    median(bert_output$robert_base_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$robert_5_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$robert_20_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$robert_50_epoc_gs_corr_gamma, na.rm = TRUE),
    
    median(bert_output$add_new_layer_bert_30_epoc_gs_corr_gamma, na.rm = TRUE),
    median(bert_output$add_new_layer_bert_50_epoc_gs_corr_gamma , na.rm = TRUE),
    median(bert_output$add_new_layer_bert_100_epoc_gs_corr_gamma, na.rm = TRUE)
    
    
  )
)

View(output)

output = data.frame(
  c(
    median(bert_output$tfidf_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$bert_gs_corr_kendall, na.rm = TRUE),
    
    median(bert_output$fine_tuned_bert_5_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_10_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_20_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_40_epoc_gs_corr_kendall, na.rm = TRUE),
    
    median(bert_output$few_layers_bert_v1_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$few_layers_bert_v2_gs_corr_kendall, na.rm = TRUE),
    
    median(bert_output$robert_base_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$robert_5_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$robert_20_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$robert_50_epoc_gs_corr_kendall, na.rm = TRUE),
    
    median(bert_output$add_new_layer_bert_30_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$add_new_layer_bert_50_epoc_gs_corr_kendall, na.rm = TRUE),
    median(bert_output$add_new_layer_bert_100_epoc_gs_corr_kendall, na.rm = TRUE)
    
  )
)

View(output)


output = data.frame(
  c(
    median(bert_output$tfidf_gs_corr_sp, na.rm = TRUE),
    median(bert_output$bert_gs_corr_sp, na.rm = TRUE),
    
    median(bert_output$fine_tuned_bert_5_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_10_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_20_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$fine_tuned_bert_40_epoc_gs_corr_sp, na.rm = TRUE),
    
    median(bert_output$few_layers_bert_v1_gs_corr_sp, na.rm = TRUE),
    median(bert_output$few_layers_bert_v2_gs_corr_sp, na.rm = TRUE),
    
    median(bert_output$robert_base_gs_corr_sp, na.rm = TRUE),
    median(bert_output$robert_5_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$robert_20_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$robert_50_epoc_gs_corr_sp, na.rm = TRUE),
    
    median(bert_output$add_new_layer_bert_30_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$add_new_layer_bert_50_epoc_gs_corr_sp, na.rm = TRUE),
    median(bert_output$add_new_layer_bert_100_epoc_gs_corr_sp, na.rm = TRUE)
    
  )
)

View(output)


#------------ Calculating NDCG at k. k = 5 ------------------ #
#------------ Will be looking at top 5 recipes in recipe 2 for every recipe in recipe 1 -------- #

View(bert_data_cv1_rank %>%
       filter(title_Recipe1_mod == "Creamy Corn") %>%
       select(c(title_Recipe1_mod, title_Recipe2_mod, gs_similarity, gs_rank)))

#------------ Recipes in Recipe 2 can have ties. Hence, selecting only the ones with <= 10 items -------- #
gs_selected_data <- bert_data_cv1_rank %>%
  filter(title_Recipe1_mod != title_Recipe2_mod) %>%
  group_by(title_Recipe1_mod, gs_rank) %>%
  summarise(tot_count = n()) %>%
  mutate(cumulative_items = cumsum(tot_count)) %>%
  filter(cumulative_items <= 10) %>%
  group_by(title_Recipe1_mod) %>%
  summarise(gs_rank_max = max(gs_rank),
            cumulative_items_max = max(cumulative_items))

gs_selected_data_rank <- bert_data_cv1_rank %>% 
  filter(title_Recipe1_mod != title_Recipe2_mod) %>%
  arrange(title_Recipe1_mod, title_Recipe2_mod) %>%
  group_by(title_Recipe1_mod)

gs_selected_data_rank <- as.data.table(gs_selected_data_rank)
gs_selected_data_rank[,gs_row_num := frank(.SD, -gs_similarity, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank[,tfidf_row_num := frank(.SD, -tfidf_similarity, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,bert_row_num := frank(.SD, -bert_similarity, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank[,fine_tuned_bert_5_epoc_row_num := frank(.SD, -fine_tuned_bert_similarity_5_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,fine_tuned_bert_10_epoc_row_num := frank(.SD, -fine_tuned_bert_similarity_10_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,fine_tuned_bert_20_epoc_row_num := frank(.SD, -fine_tuned_bert_similarity_20_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,fine_tuned_bert_40_epoc_row_num := frank(.SD, -fine_tuned_bert_similarity_40_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank[,robert_row_num := frank(.SD, -robert_base_similarity, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,robert_5_epoc_row_num := frank(.SD, -robert_similarity_5_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,robert_20_epoc_row_num := frank(.SD, -robert_similarity_20_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,robert_50_epoc_row_num := frank(.SD, -robert_similarity_50_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank[,few_layers_bert_v1_row_num := frank(.SD, -few_layers_bert_similarity_v1, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,few_layers_bert_v2_row_num := frank(.SD, -few_layers_bert_similarity_v2, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank[,add_new_layer_bert_30_row_num := frank(.SD, -add_new_layer_bert_similarity_30_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,add_new_layer_bert_50_row_num := frank(.SD, -add_new_layer_bert_similarity_50_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank[,add_new_layer_bert_100_row_num := frank(.SD, -add_new_layer_bert_similarity_100_epoc, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]


gs_selected_data_rank_v2 <- inner_join(gs_selected_data_rank,
                                       gs_selected_data,
                                       by = c("title_Recipe1_mod" = "title_Recipe1_mod")) %>%
  filter(gs_rank <= gs_rank_max)


#---------- Calculating relevance ------------ #
gs_selected_data_rank_v3 <- gs_selected_data_rank_v2 %>% 
  select(title_Recipe1_mod, 
         title_Recipe2_mod,
         gs_rank, 
         gs_row_num, 
         tfidf_row_num,
         bert_row_num,
         
         fine_tuned_bert_5_epoc_row_num,
         fine_tuned_bert_10_epoc_row_num,
         fine_tuned_bert_20_epoc_row_num,
         fine_tuned_bert_40_epoc_row_num,
         
         robert_row_num,
         robert_5_epoc_row_num,
         robert_20_epoc_row_num,
         robert_50_epoc_row_num,
         
         few_layers_bert_v1_row_num,
         few_layers_bert_v2_row_num,
         
         add_new_layer_bert_30_row_num,
         add_new_layer_bert_50_row_num,
         add_new_layer_bert_100_row_num
  ) %>%
  group_by(title_Recipe1_mod, gs_rank) %>% 
  mutate(gs_rank_groups = paste(gs_row_num, collapse = ",")) %>%
  mutate(
    tfidf_relevance = ifelse(tfidf_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    bert_relevance = ifelse(bert_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    
    fine_tuned_bert_5_epoc_relevance = ifelse(fine_tuned_bert_5_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    fine_tuned_bert_10_epoc_relevance = ifelse(fine_tuned_bert_10_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    fine_tuned_bert_20_epoc_relevance = ifelse(fine_tuned_bert_20_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    fine_tuned_bert_40_epoc_relevance = ifelse(fine_tuned_bert_40_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    
    robert_relevance = ifelse(robert_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    robert_5_epoc_relevance = ifelse(robert_5_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    robert_20_epoc_relevance = ifelse(robert_20_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    robert_50_epoc_relevance = ifelse(robert_50_epoc_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    
    few_layers_bert_v1_relevance = ifelse(few_layers_bert_v1_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    few_layers_bert_v2_relevance = ifelse(few_layers_bert_v2_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    
    add_new_layer_bert_30_epoc_relevance = ifelse(add_new_layer_bert_30_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    add_new_layer_bert_50_epoc_relevance = ifelse(add_new_layer_bert_50_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0),
    add_new_layer_bert_100_epoc_relevance = ifelse(add_new_layer_bert_100_row_num %in% unlist(strsplit(gs_rank_groups, ",", fixed = FALSE)),1,0)
  )



gs_selected_data_rank_v3 <- as.data.table(gs_selected_data_rank_v3)

gs_selected_data_rank_v3[,tfidf_row_num_v2 := frank(.SD, -tfidf_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,bert_row_num_v2 := frank(.SD, -bert_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank_v3[,fine_tuned_bert_5_epoc_row_num_v2 := frank(.SD, -fine_tuned_bert_5_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,fine_tuned_bert_10_epoc_row_num_v2 := frank(.SD, -fine_tuned_bert_10_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,fine_tuned_bert_20_epoc_row_num_v2 := frank(.SD, -fine_tuned_bert_20_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,fine_tuned_bert_40_epoc_row_num_v2 := frank(.SD, -fine_tuned_bert_40_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank_v3[,robert_row_num_v2 := frank(.SD, -robert_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,robert_5_epoc_row_num_v2 := frank(.SD, -robert_5_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,robert_20_epoc_row_num_v2 := frank(.SD, -robert_20_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,robert_50_epoc_row_num_v2 := frank(.SD, -robert_50_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank_v3[,few_layers_bert_v1_row_num_v2 := frank(.SD, -few_layers_bert_v1_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,few_layers_bert_v2_row_num_v2 := frank(.SD, -few_layers_bert_v2_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]

gs_selected_data_rank_v3[,add_new_layer_bert_30_epoc_row_num_v2 := frank(.SD, -add_new_layer_bert_30_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,add_new_layer_bert_50_epoc_row_num_v2 := frank(.SD, -add_new_layer_bert_50_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]
gs_selected_data_rank_v3[,add_new_layer_bert_100_epoc_row_num_v2 := frank(.SD, -add_new_layer_bert_100_epoc_relevance, title_Recipe2_mod, na.last = TRUE, ties.method = "min"),by = .(title_Recipe1_mod)]


#----------- Calculating DCG ----------- #
gs_selected_data_rank_v3$tfidf_dcg <- gs_selected_data_rank_v3$tfidf_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$bert_dcg <- gs_selected_data_rank_v3$bert_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)

gs_selected_data_rank_v3$fine_tuned_bert_5_epoc_dcg <- gs_selected_data_rank_v3$fine_tuned_bert_5_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$fine_tuned_bert_10_epoc_dcg <- gs_selected_data_rank_v3$fine_tuned_bert_10_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$fine_tuned_bert_20_epoc_dcg <- gs_selected_data_rank_v3$fine_tuned_bert_20_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$fine_tuned_bert_40_epoc_dcg <- gs_selected_data_rank_v3$fine_tuned_bert_40_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)

gs_selected_data_rank_v3$robert_dcg <- gs_selected_data_rank_v3$robert_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$robert_5_epoc_dcg <- gs_selected_data_rank_v3$robert_5_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$robert_20_epoc_dcg <- gs_selected_data_rank_v3$robert_20_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$robert_50_epoc_dcg <- gs_selected_data_rank_v3$robert_50_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)

gs_selected_data_rank_v3$few_layers_bert_v1_dcg <- gs_selected_data_rank_v3$few_layers_bert_v1_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$few_layers_bert_v2_dcg <- gs_selected_data_rank_v3$few_layers_bert_v2_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)

gs_selected_data_rank_v3$add_new_layer_bert_30_epoc_dcg <- gs_selected_data_rank_v3$add_new_layer_bert_30_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$add_new_layer_bert_50_epoc_dcg <- gs_selected_data_rank_v3$add_new_layer_bert_50_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)
gs_selected_data_rank_v3$add_new_layer_bert_100_epoc_dcg <- gs_selected_data_rank_v3$add_new_layer_bert_100_epoc_relevance / log2(gs_selected_data_rank_v3$gs_row_num + 1)



#----------- Calculating IDCG ----------- #
gs_selected_data_rank_v3$tfidf_idcg <- gs_selected_data_rank_v3$tfidf_relevance / log2(gs_selected_data_rank_v3$tfidf_row_num_v2 + 1)
gs_selected_data_rank_v3$bert_idcg <- gs_selected_data_rank_v3$bert_relevance / log2(gs_selected_data_rank_v3$bert_row_num_v2 + 1)

gs_selected_data_rank_v3$fine_tuned_bert_5_epoc_idcg <- gs_selected_data_rank_v3$fine_tuned_bert_5_epoc_relevance / log2(gs_selected_data_rank_v3$fine_tuned_bert_5_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$fine_tuned_bert_10_epoc_idcg <- gs_selected_data_rank_v3$fine_tuned_bert_10_epoc_relevance / log2(gs_selected_data_rank_v3$fine_tuned_bert_10_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$fine_tuned_bert_20_epoc_idcg <- gs_selected_data_rank_v3$fine_tuned_bert_20_epoc_relevance / log2(gs_selected_data_rank_v3$fine_tuned_bert_20_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$fine_tuned_bert_40_epoc_idcg <- gs_selected_data_rank_v3$fine_tuned_bert_40_epoc_relevance / log2(gs_selected_data_rank_v3$fine_tuned_bert_40_epoc_row_num_v2 + 1)


gs_selected_data_rank_v3$robert_idcg <- gs_selected_data_rank_v3$robert_relevance / log2(gs_selected_data_rank_v3$robert_row_num_v2 + 1)
gs_selected_data_rank_v3$robert_5_epoc_idcg <- gs_selected_data_rank_v3$robert_5_epoc_relevance / log2(gs_selected_data_rank_v3$robert_5_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$robert_20_epoc_idcg <- gs_selected_data_rank_v3$robert_20_epoc_relevance / log2(gs_selected_data_rank_v3$robert_20_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$robert_50_epoc_idcg <- gs_selected_data_rank_v3$robert_50_epoc_relevance / log2(gs_selected_data_rank_v3$robert_50_epoc_row_num_v2 + 1)

gs_selected_data_rank_v3$few_layers_bert_v1_idcg <- gs_selected_data_rank_v3$few_layers_bert_v1_relevance / log2(gs_selected_data_rank_v3$few_layers_bert_v1_row_num_v2 + 1)
gs_selected_data_rank_v3$few_layers_bert_v2_idcg <- gs_selected_data_rank_v3$few_layers_bert_v2_relevance / log2(gs_selected_data_rank_v3$few_layers_bert_v2_row_num_v2 + 1)

gs_selected_data_rank_v3$add_new_layer_bert_30_epoc_idcg <- gs_selected_data_rank_v3$add_new_layer_bert_30_epoc_relevance / log2(gs_selected_data_rank_v3$add_new_layer_bert_30_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$add_new_layer_bert_50_epoc_idcg <- gs_selected_data_rank_v3$add_new_layer_bert_50_epoc_relevance / log2(gs_selected_data_rank_v3$add_new_layer_bert_50_epoc_row_num_v2 + 1)
gs_selected_data_rank_v3$add_new_layer_bert_100_epoc_idcg <- gs_selected_data_rank_v3$add_new_layer_bert_100_epoc_relevance / log2(gs_selected_data_rank_v3$add_new_layer_bert_100_epoc_row_num_v2 + 1)


#----------- Calculating NDCG ----------- #

gs_selected_data_rank_v4 <- gs_selected_data_rank_v3 %>%
  select(c(title_Recipe1_mod, 
           title_Recipe2_mod,
           
           tfidf_dcg,
           bert_dcg,
           
           fine_tuned_bert_5_epoc_dcg,
           fine_tuned_bert_10_epoc_dcg,
           fine_tuned_bert_20_epoc_dcg,
           fine_tuned_bert_40_epoc_dcg,
           
           robert_dcg,
           robert_5_epoc_dcg,
           robert_20_epoc_dcg,
           robert_50_epoc_dcg,
           
           few_layers_bert_v1_dcg,
           few_layers_bert_v2_dcg,
           
           add_new_layer_bert_30_epoc_dcg,
           add_new_layer_bert_50_epoc_dcg,
           add_new_layer_bert_100_epoc_dcg,
           
           tfidf_idcg,
           bert_idcg,
           
           fine_tuned_bert_5_epoc_idcg,
           fine_tuned_bert_10_epoc_idcg,
           fine_tuned_bert_20_epoc_idcg,
           fine_tuned_bert_40_epoc_idcg,
           
           robert_idcg,
           robert_5_epoc_idcg,
           robert_20_epoc_idcg,
           robert_50_epoc_idcg,
           
           few_layers_bert_v1_idcg,
           few_layers_bert_v2_idcg,
           
           add_new_layer_bert_30_epoc_idcg,
           add_new_layer_bert_50_epoc_idcg,
           add_new_layer_bert_100_epoc_idcg
  )) %>%
  group_by(title_Recipe1_mod) %>%
  summarise(
    tfidf_dcg = sum(tfidf_dcg),
    bert_dcg = sum(bert_dcg),
    
    fine_tuned_bert_5_epoc_dcg = sum(fine_tuned_bert_40_epoc_dcg),
    fine_tuned_bert_10_epoc_dcg = sum(fine_tuned_bert_10_epoc_dcg),
    fine_tuned_bert_20_epoc_dcg = sum(fine_tuned_bert_20_epoc_dcg),
    fine_tuned_bert_40_epoc_dcg = sum(fine_tuned_bert_40_epoc_dcg),
    
    robert_dcg = sum(robert_dcg),
    robert_5_epoc_dcg = sum(robert_5_epoc_dcg),
    robert_20_epoc_dcg = sum(robert_20_epoc_dcg),
    robert_50_epoc_dcg = sum(robert_50_epoc_dcg),
    
    few_layers_bert_v1_dcg = sum(few_layers_bert_v1_dcg),
    few_layers_bert_v2_dcg = sum(few_layers_bert_v2_dcg),
    
    add_new_layer_bert_30_epoc_dcg = sum(add_new_layer_bert_30_epoc_dcg),
    add_new_layer_bert_50_epoc_dcg = sum(add_new_layer_bert_50_epoc_dcg),
    add_new_layer_bert_100_epoc_dcg = sum(add_new_layer_bert_100_epoc_dcg),
    
    
    tfidf_idcg = sum(tfidf_idcg),
    bert_idcg = sum(bert_idcg),
    
    fine_tuned_bert_5_epoc_idcg = sum(fine_tuned_bert_40_epoc_idcg),
    fine_tuned_bert_10_epoc_idcg = sum(fine_tuned_bert_10_epoc_idcg),
    fine_tuned_bert_20_epoc_idcg = sum(fine_tuned_bert_20_epoc_idcg),
    fine_tuned_bert_40_epoc_idcg = sum(fine_tuned_bert_40_epoc_idcg),
    
    robert_idcg = sum(robert_idcg),
    robert_5_epoc_idcg = sum(robert_5_epoc_idcg),
    robert_20_epoc_idcg = sum(robert_20_epoc_idcg),
    robert_50_epoc_idcg = sum(robert_50_epoc_idcg),
    
    few_layers_bert_v1_idcg = sum(few_layers_bert_v1_idcg),
    few_layers_bert_v2_idcg = sum(few_layers_bert_v2_idcg),
    
    add_new_layer_bert_30_epoc_idcg = sum(add_new_layer_bert_30_epoc_idcg),
    add_new_layer_bert_50_epoc_idcg = sum(add_new_layer_bert_50_epoc_idcg),
    add_new_layer_bert_100_epoc_idcg = sum(add_new_layer_bert_100_epoc_idcg)
  ) %>%
  mutate(
    tfidf_ndcg = tfidf_dcg / tfidf_idcg,
    bert_ndcg = bert_dcg / bert_idcg,
    
    fine_tuned_bert_5_epoc_ndcg = fine_tuned_bert_5_epoc_dcg / fine_tuned_bert_5_epoc_idcg,
    fine_tuned_bert_10_epoc_ndcg = fine_tuned_bert_10_epoc_dcg / fine_tuned_bert_10_epoc_idcg,
    fine_tuned_bert_20_epoc_ndcg = fine_tuned_bert_20_epoc_dcg / fine_tuned_bert_20_epoc_idcg,
    fine_tuned_bert_40_epoc_ndcg = fine_tuned_bert_40_epoc_dcg / fine_tuned_bert_40_epoc_idcg,
    
    robert_ndcg = robert_dcg / robert_idcg,
    robert_5_epoc_ndcg = robert_5_epoc_dcg / robert_5_epoc_idcg,
    robert_20_epoc_ndcg = robert_20_epoc_dcg / robert_20_epoc_idcg,
    robert_50_epoc_ndcg = robert_50_epoc_dcg / robert_50_epoc_idcg,
    
    few_layers_bert_v1_ndcg = few_layers_bert_v1_dcg / few_layers_bert_v1_idcg,
    few_layers_bert_v2_ndcg = few_layers_bert_v2_dcg / few_layers_bert_v2_idcg,
    
    add_new_layer_bert_30_epoc_ndcg = add_new_layer_bert_30_epoc_dcg / add_new_layer_bert_30_epoc_idcg,
    add_new_layer_bert_50_epoc_ndcg = add_new_layer_bert_50_epoc_dcg / add_new_layer_bert_50_epoc_idcg,
    add_new_layer_bert_100_epoc_ndcg = add_new_layer_bert_100_epoc_dcg / add_new_layer_bert_100_epoc_idcg
  )

gs_selected_data_rank_v4$tfidf_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$tfidf_ndcg),0,gs_selected_data_rank_v4$tfidf_ndcg)
gs_selected_data_rank_v4$bert_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$bert_ndcg),0,gs_selected_data_rank_v4$bert_ndcg)

gs_selected_data_rank_v4$fine_tuned_bert_5_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$fine_tuned_bert_5_epoc_ndcg),0,gs_selected_data_rank_v4$fine_tuned_bert_5_epoc_ndcg)
gs_selected_data_rank_v4$fine_tuned_bert_10_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$fine_tuned_bert_10_epoc_ndcg),0,gs_selected_data_rank_v4$fine_tuned_bert_10_epoc_ndcg)
gs_selected_data_rank_v4$fine_tuned_bert_20_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$fine_tuned_bert_20_epoc_ndcg),0,gs_selected_data_rank_v4$fine_tuned_bert_20_epoc_ndcg)
gs_selected_data_rank_v4$fine_tuned_bert_40_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$fine_tuned_bert_40_epoc_ndcg),0,gs_selected_data_rank_v4$fine_tuned_bert_40_epoc_ndcg)

gs_selected_data_rank_v4$robert_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$robert_ndcg),0,gs_selected_data_rank_v4$robert_ndcg)
gs_selected_data_rank_v4$robert_5_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$robert_5_epoc_ndcg),0,gs_selected_data_rank_v4$robert_5_epoc_ndcg)
gs_selected_data_rank_v4$robert_20_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$robert_20_epoc_ndcg),0,gs_selected_data_rank_v4$robert_20_epoc_ndcg)
gs_selected_data_rank_v4$robert_50_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$robert_50_epoc_ndcg),0,gs_selected_data_rank_v4$robert_50_epoc_ndcg)

gs_selected_data_rank_v4$few_layers_bert_v1_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$few_layers_bert_v1_ndcg),0,gs_selected_data_rank_v4$few_layers_bert_v1_ndcg)
gs_selected_data_rank_v4$few_layers_bert_v2_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$few_layers_bert_v2_ndcg),0,gs_selected_data_rank_v4$few_layers_bert_v2_ndcg)

gs_selected_data_rank_v4$add_new_layer_bert_30_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$add_new_layer_bert_30_epoc_ndcg),0,gs_selected_data_rank_v4$add_new_layer_bert_30_epoc_ndcg)
gs_selected_data_rank_v4$add_new_layer_bert_50_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$add_new_layer_bert_50_epoc_ndcg),0,gs_selected_data_rank_v4$add_new_layer_bert_50_epoc_ndcg)
gs_selected_data_rank_v4$add_new_layer_bert_100_epoc_ndcg <- ifelse(is.na(gs_selected_data_rank_v4$add_new_layer_bert_100_epoc_ndcg),0,gs_selected_data_rank_v4$add_new_layer_bert_100_epoc_ndcg)



ndcg_output <- as.data.frame(
  c(
    median(gs_selected_data_rank_v4$tfidf_ndcg),
    median(gs_selected_data_rank_v4$bert_ndcg),
    
    median(gs_selected_data_rank_v4$fine_tuned_bert_5_epoc_ndcg),
    median(gs_selected_data_rank_v4$fine_tuned_bert_10_epoc_ndcg),
    median(gs_selected_data_rank_v4$fine_tuned_bert_20_epoc_ndcg),
    median(gs_selected_data_rank_v4$fine_tuned_bert_40_epoc_ndcg),
    
    median(gs_selected_data_rank_v4$robert_ndcg),
    median(gs_selected_data_rank_v4$robert_5_epoc_ndcg),
    median(gs_selected_data_rank_v4$robert_20_epoc_ndcg),
    median(gs_selected_data_rank_v4$robert_50_epoc_ndcg),
    
    median(gs_selected_data_rank_v4$few_layers_bert_v1_ndcg),
    median(gs_selected_data_rank_v4$few_layers_bert_v2_ndcg),
    
    median(gs_selected_data_rank_v4$add_new_layer_bert_30_epoc_ndcg),
    median(gs_selected_data_rank_v4$add_new_layer_bert_50_epoc_ndcg),
    median(gs_selected_data_rank_v4$add_new_layer_bert_100_epoc_ndcg)
  )
)


View(ndcg_output)




#---------------- End of NDCG Calculations ---------------------- #